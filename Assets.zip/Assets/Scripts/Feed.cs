using UnityEngine;

public class Feed : MonoBehaviour
{
    private Camera cam;
    [SerializeField] private GameObject newEat;
    [SerializeField] private GameObject newArchaea;
    [SerializeField] private GameObject parentPlace;
    private Transform place;
    private AudioSource audioSource;

    private void Start()
    {
        cam = Camera.main;
        audioSource = GetComponent<AudioSource>();
        place = parentPlace.GetComponent<Transform>();
    }

    private void OnMouseDown()
    {
        Vector3 position = cam.ScreenToWorldPoint(Input.mousePosition);
        position.z = 0;
        if (GameManager.gameManager.action == GameManager.ActionMode.Feed)
        {
            Instantiate(newEat, position, transform.rotation, place);
            audioSource.PlayOneShot(audioSource.clip);
        }
        if (GameManager.gameManager.action == GameManager.ActionMode.Seed)
        {
            GameManager.gameManager.InstantiateArchaea(position);
        }
    }
}
