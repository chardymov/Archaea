using System;
using System.Collections;
using UnityEngine;
using Random = UnityEngine.Random;

public class Archaea : MonoBehaviour
{
    private Rigidbody2D body;
    private Animator animator;
    private new AudioSource audio;
    private float deltaRotation;
    private bool moving;
    private Archaea otherArcheae;
    private Color archaeaColor;
    public Archaea thisArchaea;
    
    [SerializeField] private int eated;
    [SerializeField] private bool birthArchaea;
    [SerializeField] private bool dieArchaea;
    [SerializeField] private Transform pos1;
    [SerializeField] private Transform pos2;
    [SerializeField] private Transform pos3;
    [SerializeField] private GameObject newArchaea;
    [SerializeField] private GameObject newEat;
    [SerializeField] private GameObject circle1;
    [SerializeField] private GameObject circle2;
    [SerializeField] private GameObject circle3;

    private void Awake()
    {
        thisArchaea = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        body = gameObject.GetComponent<Rigidbody2D>();
        animator = gameObject.GetComponent<Animator>();
        audio = gameObject.GetComponent<AudioSource>();
        eated = 0;
        moving = false;
        deltaRotation = 0;
        birthArchaea = false;
        dieArchaea = false;
        circle1.SetActive(false);
        circle2.SetActive(false);
        circle3.SetActive(false);
        archaeaColor = GetComponent<SpriteRenderer>().color;
        GameManager.gameManager.archaeaList.Add(archaeaColor);
    }

    // Update is called once per frame
    void Update()
    {
        if (birthArchaea) return;
        if (dieArchaea) return;
        RandomAction();
    }

    private void RandomAction()
    {
        float randomSeed = Random.Range(0, 100);
        if (randomSeed < 1) deltaRotation = Random.Range(-0.1f, 0.1f);
        if (randomSeed > 98)
        {
            if (!moving) StartCoroutine(WaitAndRun());
        }
        body.rotation += deltaRotation;
    }

    IEnumerator WaitAndRun()
    {
        moving = true;
        body.velocity = new Vector2(Random.Range(-1f, 1f), Random.Range(-1f, 1f));
        yield return new WaitForSeconds(Random.Range(5, 20));
        moving = false;
    }

    public void EatFeed()
    {
        eated += 1;
        if (eated == 1) circle1.SetActive(true);
        if (eated == 2) circle2.SetActive(true);
        if (eated >= 3)
        {
            circle3.SetActive(true);
            birthArchaea = true;
            animator.SetTrigger("transitionBirth");
        }
    }
    
    public void EndBirth()
    {
        GameObject arc1 = Instantiate(newArchaea, pos1.position, transform.rotation, transform.parent);
        GameObject arc2 = Instantiate(newArchaea, pos2.position, transform.rotation, transform.parent);
        GameManager.gameManager.UpdateCounter(1);
        GameManager.gameManager.GetComponent<AudioSource>().PlayOneShot(GameManager.gameManager.GetComponent<AudioSource>().clip);
        Destroy(gameObject);
    }

    public void EndDie()
    {
        Instantiate(newEat, pos1.position, transform.rotation, transform.parent);
        Instantiate(newEat, pos2.position, transform.rotation, transform.parent);
        Instantiate(newEat, pos3.position, transform.rotation, transform.parent);
        GameManager.gameManager.UpdateCounter(-1);
        Destroy((gameObject));
    }
    
    private void OnMouseDown()
    {
        if (GameManager.gameManager.action == GameManager.ActionMode.Kill)
        {
            KillArchaea();
        }
    }

    private void KillArchaea()
    {
        animator.SetTrigger("transitionDie");
        dieArchaea = true;
        audio.PlayOneShot(audio.clip);
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        otherArcheae = other.collider.GetComponentInParent<Archaea>();
        if (otherArcheae != null)
        {
            Color otherColor = otherArcheae.GetComponent<SpriteRenderer>().color;
            Color thisColor = GetComponent<SpriteRenderer>().color;
            if ((otherColor != thisColor) & (thisArchaea.eated > otherArcheae.eated)) otherArcheae.thisArchaea.KillArchaea();
        }
    }

    private void OnDestroy()
    {
        if (GameManager.gameManager == null) return;
        GameManager.gameManager.archaeaList.Remove(archaeaColor);
        GameManager.gameManager.CheckColony();
    }
}
