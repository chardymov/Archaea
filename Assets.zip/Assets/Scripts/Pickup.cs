using UnityEngine;

public class Pickup : MonoBehaviour
{
    private Archaea otherArchaea;
    private void OnTriggerEnter2D(Collider2D other)
    {
        otherArchaea = other.GetComponentInParent<Archaea>();
        otherArchaea.EatFeed();
        Destroy(gameObject);
    }
}
