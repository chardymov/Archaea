using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartScreen : MonoBehaviour
{
    [SerializeField] private GameObject scoreText;
    private CursorMode cursorMode = CursorMode.Auto;
    private Vector2 hotSpot = Vector2.zero;
    
    void Start()
    {
        scoreText.GetComponent<TMP_Text>().text = "Best score: " + PlayerPrefs.GetInt("Score", 0);
        Cursor.SetCursor(null, hotSpot, cursorMode);
    }
    
    public void StartGame()
    {
        SceneManager.LoadScene("MainScene");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
