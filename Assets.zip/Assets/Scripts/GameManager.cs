using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class GameManager : MonoBehaviour
{
    public static GameManager gameManager;
    public int archaeaCount;
    private int bestScore;
    public List<Color> archaeaList;
    [SerializeField] private GameObject winPanel;
    [SerializeField] private GameObject text;
    [SerializeField] public ActionMode action;
    [SerializeField] private Texture2D cursorTextureSeed;
    [SerializeField] private Texture2D cursorTextureFeed;
    [SerializeField] private Texture2D cursorTextureKill;
    [SerializeField] private GameObject newArchaea;
    [SerializeField] private GameObject parentPlace;
    private Transform place;
    public CursorMode cursorMode = CursorMode.Auto;
    public Vector2 hotSpot = Vector2.zero;
    private new AudioSource audio;
    
    // Start is called before the first frame update
    void Awake()
    {
        gameManager = this;
       /* if (gameManager == null) gameManager = this;
        else if (gameManager != this)
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(this);*/
    }

    private void Start()
    {
        audio = GetComponent<AudioSource>();
        place = parentPlace.GetComponent<Transform>();
        winPanel.SetActive(false);
        action = ActionMode.None;
        Cursor.SetCursor(null, hotSpot, cursorMode);
        archaeaCount = 5;
        text.GetComponent<Text>().text = "Archaea colony: " + archaeaCount;
    }

    public void UpdateCounter(int count)
    {
        archaeaCount += count;
        text.GetComponent<Text>().text = "Archaea colony: " + archaeaCount;
    }

    public void PressSeed()
    {
        action = ActionMode.Seed;
        Cursor.SetCursor(cursorTextureSeed, hotSpot, cursorMode);
    }
    
    public void PressFeed()
    {
        action = ActionMode.Feed;
        Cursor.SetCursor(cursorTextureFeed, hotSpot, cursorMode);
    }

    public void PressKill()
    {
        action = ActionMode.Kill;
        Cursor.SetCursor(cursorTextureKill, hotSpot, cursorMode);
    }

    public void InstantiateArchaea(Vector3 position)
    {
        Color newColor = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f), 1);
        GameObject archaea = Instantiate(newArchaea, position, transform.rotation, place);
        archaea.GetComponent<SpriteRenderer>().color = newColor;
        UpdateCounter(1);
        audio.PlayOneShot(audio.clip);
    }

    public void CheckColony()
    {
        if (archaeaList.Count < 1) return;
        Color firstColor = archaeaList[0];
        foreach (var color in archaeaList)
        {
            if (firstColor != color) return;
        }

        if (winPanel != null)
        {
            winPanel.SetActive(true);
            bestScore = PlayerPrefs.GetInt("Score", 0);
            if (archaeaCount > bestScore)
            {
                PlayerPrefs.SetInt("Score", archaeaCount);
                PlayerPrefs.Save();
            }
        }
    }

    public void ContinueGame()
    {
        if (winPanel != null) winPanel.SetActive(false);
    }
    
    public void QuitGame()
    {
        SceneManager.LoadScene("StartScene");
    }
    
    public enum ActionMode { None, Seed, Feed, Kill}
}


